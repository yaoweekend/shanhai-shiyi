// UI 层（DOM 覆盖层）。渲染层负责画布内的 HUD，这里负责所有屏幕。
// 上架硬门槛（规格 §15）：隐私政策页、关于/许可页、启动自检提示页——三件都在这里。

import { CHARACTERS, BATCH1_CHARACTERS, CHARACTER_BY_ID } from '../content/characters.js';
import { BATCH1_WEAPONS, WEAPON_BY_ID, levelStats, WEAPON_KIND_CN } from '../content/weapons.js';
import { BATCH1_PASSIVES, PASSIVE_BY_ID } from '../content/passives.js';
import { FUSIONS, FUSION_BY_ID } from '../content/fusions.js';
import { SERIES } from '../content/series.js';
import { CHANNEL_BY_ID, formatChannelBonus } from '../core/channels.js';
import { HOOK_LIST } from '../core/hooks.js';
import { TRIALS, trialProgress, isTrialDone, codexBySeries } from '../meta/meta.js';
import { COMMON_NODES, SERIES_NODES, SERIES_TRAITS, SERIES_IDS, SERIES_BALANCE_CAP, inscriptionRefund, seriesMaxed } from '../meta/inscriptions.js';
import { SLOTS, slotById } from '../assets/manifest.js';
import { placeholderStats, getPlaceholder, getAsset, passiveIconSlot } from '../assets/generator.js';
import { VERSION, SLOT_WEAPONS, SLOT_PASSIVES, WEAPON_MAX_LEVEL, PASSIVE_MAX_LEVEL, PLAYER_BASE, CAP_ENEMIES, CAP_PLAYER_BULLETS } from '../config.js';
import { guessEnvironment } from './webview-check.js';

const $ = (id) => document.getElementById(id);
const SERIES_SEALS = { shan: '山經', hai: '海經', huang: '大荒', tian: '天問', ling: '靈山', kun: '昆侖' };

// 两层轮廓共用 13 个横向锚点，切换神系时可逐点变形。
const MOTIF_SHAPES = {
  common: { back: [156, 148, 151, 137, 144, 126, 137, 130, 147, 132, 141, 149, 145], front: [174, 170, 172, 158, 167, 153, 162, 155, 170, 158, 166, 174, 170], smooth: .2 },
  shan: { back: [160, 134, 141, 92, 135, 111, 149, 119, 145, 83, 139, 116, 151], front: [174, 157, 166, 138, 99, 143, 160, 119, 170, 146, 128, 150, 166], smooth: 0 },
  hai: { back: [123, 99, 103, 126, 145, 137, 108, 98, 121, 145, 138, 105, 92], front: [157, 139, 144, 163, 171, 154, 139, 149, 168, 169, 151, 135, 140], smooth: 1 },
  huang: { back: [153, 153, 142, 142, 151, 151, 130, 130, 151, 151, 139, 139, 153], front: [174, 174, 164, 164, 174, 157, 157, 174, 174, 162, 162, 174, 174], smooth: 0 },
  tian: { back: [172, 170, 172, 164, 166, 174, 172, 163, 165, 173, 171, 167, 171], front: [177, 176, 177, 174, 175, 178, 177, 174, 175, 177, 177, 175, 176], smooth: .7 },
  ling: { back: [151, 150, 153, 148, 151, 150, 154, 149, 152, 148, 152, 151, 153], front: [174, 172, 174, 170, 173, 172, 175, 171, 173, 170, 174, 172, 174], smooth: .25 },
  kun: { back: [164, 135, 108, 82, 61, 44, 38, 44, 61, 82, 108, 135, 164], front: [174, 174, 158, 158, 136, 136, 111, 136, 136, 158, 158, 174, 174], smooth: 0 },
};
const backdropStates = new WeakMap();

function motifPath(points, smooth) {
  let path = `M0 ${points[0].toFixed(1)}`;
  for (let i = 0; i < points.length - 1; i++) {
    const delta = points[i + 1] - points[i];
    const slopeA = (points[Math.min(i + 1, 12)] - points[Math.max(i - 1, 0)]) / 2;
    const slopeB = (points[Math.min(i + 2, 12)] - points[i]) / 2;
    const controlA = points[i] + (delta * (1 - smooth) + slopeA * smooth) / 3;
    const controlB = points[i + 1] - (delta * (1 - smooth) + slopeB * smooth) / 3;
    path += `C${(i * 50 + 16.7).toFixed(1)} ${controlA.toFixed(1)} ${((i + 1) * 50 - 16.7).toFixed(1)} ${controlB.toFixed(1)} ${(i + 1) * 50} ${points[i + 1].toFixed(1)}`;
  }
  return `${path}V180H0Z`;
}

function mixMotif(from, to, progress) {
  return {
    back: from.back.map((value, i) => value + (to.back[i] - value) * progress),
    front: from.front.map((value, i) => value + (to.front[i] - value) * progress),
    smooth: from.smooth + (to.smooth - from.smooth) * progress,
  };
}

function drawMotif(backdrop, shape) {
  backdrop.querySelector('.motif-back').setAttribute('d', motifPath(shape.back, shape.smooth));
  backdrop.querySelector('.motif-front').setAttribute('d', motifPath(shape.front, shape.smooth));
}

function seriesBackdropMarkup(active = 'common') {
  return `<div class="series-backdrop" aria-hidden="true">${SERIES_IDS.map((id) => `
    <div class="series-backdrop-layer${active === id ? ' active' : ''}" data-series="${id}" style="--motif-color:${SERIES[id].color}"></div>`).join('')}
    <svg class="series-backdrop-art" viewBox="0 0 600 180" preserveAspectRatio="xMidYMax slice" data-morphing="false">
      <path class="motif-back"/><path class="motif-front"/>
      ${SERIES_IDS.map((id) => `<use class="series-backdrop-mark" data-series="${id}" href="#motif-mark-${id}"/>`).join('')}
    </svg></div>`;
}

function setSeriesBackdrop(host, seriesId, animate = true) {
  host.dataset.series = seriesId;
  const backdrop = host.querySelector('.series-backdrop');
  backdrop.querySelectorAll('.series-backdrop-layer').forEach((layer) => {
    layer.classList.toggle('active', layer.dataset.series === seriesId);
  });
  const art = backdrop.querySelector('.series-backdrop-art');
  art.style.setProperty('--motif-color', SERIES[seriesId]?.color || '#bfa174');
  art.dataset.motifSeries = seriesId;
  art.querySelectorAll('.series-backdrop-mark').forEach((mark) => mark.classList.toggle('active', mark.dataset.series === seriesId));
  let state = backdropStates.get(backdrop);
  const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  if (!state || !animate || reduced) {
    if (state?.frame) cancelAnimationFrame(state.frame);
    state = { current: MOTIF_SHAPES[seriesId], targetId: seriesId, running: false };
    backdropStates.set(backdrop, state);
    drawMotif(backdrop, state.current);
    art.dataset.morphing = 'false';
    return;
  }
  if (state.targetId === seriesId) return;
  if (state.running) {
    const elapsed = Math.min(1, (performance.now() - state.started) / 450);
    state.current = mixMotif(state.from, state.to, 1 - (1 - elapsed) ** 3);
    cancelAnimationFrame(state.frame);
  }
  state.from = state.current;
  state.to = MOTIF_SHAPES[seriesId];
  state.targetId = seriesId;
  state.started = performance.now();
  state.running = true;
  art.dataset.morphing = 'true';
  const step = (now) => {
    const elapsed = Math.min(1, (now - state.started) / 450);
    state.current = mixMotif(state.from, state.to, 1 - (1 - elapsed) ** 3);
    drawMotif(backdrop, state.current);
    if (elapsed < 1) state.frame = requestAnimationFrame(step);
    else { state.running = false; art.dataset.morphing = 'false'; }
  };
  state.frame = requestAnimationFrame(step);
}

/** 数值卡加成的显示（比率通道按百分比，加法通道按点数） */
function fmtStatValue(channel, value) {
  const c = CHANNEL_BY_ID[channel];
  const pct = c && (c.op === 'mul' || c.op === 'addBase' || c.op === 'cap');
  return pct ? `${Math.round(value * 100)}%` : `${Number.isInteger(value) ? value : value.toFixed(1)}`;
}

/**
 * 通道类卡片（被动升级 / 数值兜底）的"变化"行。
 * 不能复用 deltaList：那套只认武器等级表里的键（damage/cd/radius…），
 * 通道卡会整片落进"数值不变"的兜底分支（真实踩过）。
 */
function channelDeltaLine(pid_or_channel, before, after, cnOverride) {
  const c = CHANNEL_BY_ID[pid_or_channel];
  const cn = cnOverride || (c ? c.cn : pid_or_channel);
  return `<ul class="delta"><li>${cn} ${fmtStatValue(pid_or_channel, before)} → <b>${fmtStatValue(
    pid_or_channel,
    after,
  )}</b></li></ul>`;
}

export class UI {
  /**
   * @param {object} ctl 控制器（由 main.js 提供）
   *   { getSave, persist, getSettings, setSettings, audio, startRun, resumeRun,
   *     takeCard, saveAndQuit, quitRun, restart, toMenu, openEndless, hasUnfinished }
   */
  constructor(ctl) {
    this.ctl = ctl;
    this.currentCardChoices = [];
    this.selectedCardIndex = -1;
    this.selectedChar = null;
    this.selectedDifficulty = 'normal';
    this.selectedInscriptionTab = 'common';
    this.selectedInscriptionNode = 'maxHp';
    this.screens = ['menu', 'hud', 'pause', 'levelup', 'result', 'trials', 'inscriptions', 'codex', 'settings', 'about', 'privacy'];
    document.querySelector('.menu-hero').insertAdjacentHTML('afterbegin', seriesBackdropMarkup());
    this.bindGlobal();
  }

  el(name) {
    return $(`screen-${name}`);
  }

  hideAll() {
    for (const s of this.screens) {
      const el = this.el(s);
      if (el) el.hidden = true;
    }
  }

  show(name) {
    this.hideAll();
    const el = this.el(name);
    if (el) el.hidden = false;
    this.active = name;
  }

  showOverlay(name) {
    const el = this.el(name);
    if (el) el.hidden = false;
    this.active = name;
  }

  confirmAction(title, message, onConfirm) {
    if (document.querySelector('.confirm-backdrop')) return;
    const previousFocus = document.activeElement;
    const backdrop = document.createElement('div');
    backdrop.className = 'confirm-backdrop';
    backdrop.innerHTML = '<div class="confirm-panel" role="dialog" aria-modal="true" aria-labelledby="confirm-title" aria-describedby="confirm-message"><h2 id="confirm-title"></h2><p id="confirm-message"></p><div class="confirm-actions"><button type="button" data-confirm-cancel>取消</button><button type="button" class="primary" data-confirm-yes>确定</button></div></div>';
    backdrop.querySelector('#confirm-title').textContent = title;
    backdrop.querySelector('#confirm-message').textContent = message;
    const close = () => {
      backdrop.remove();
      if (previousFocus?.isConnected) previousFocus.focus();
    };
    backdrop.querySelector('[data-confirm-cancel]').addEventListener('click', close);
    backdrop.querySelector('[data-confirm-yes]').addEventListener('click', () => {
      close();
      onConfirm();
    });
    backdrop.addEventListener('click', (event) => {
      if (event.target === backdrop) close();
    });
    document.body.appendChild(backdrop);
    backdrop.querySelector('[data-confirm-cancel]').focus();
  }

  bindGlobal() {
    const back = (e) => {
      e.preventDefault();
      this.ctl.audio.play('ui');
      this.renderMenu();
      this.show('menu');
    };
    document.querySelectorAll('[data-back]').forEach((b) => b.addEventListener('click', back));

    $('btn-start').addEventListener('click', () => {
      this.ctl.audio.play('ui');
      const start = () => {
        const started = this.ctl.startRun(this.selectedChar || (this.ctl.getSave().unlocks.characters[0] || 'shanpo'), this.selectedDifficulty);
        if (!started) this.toast('先通关普通模式，才能挑战困难。');
      };
      if (this.ctl.hasUnfinished()) this.confirmAction('开启新局', '上一局尚未完成。开启新局会覆盖旧局存档，确定继续吗？', start);
      else start();
    });
    for (const difficulty of ['normal', 'hard']) {
      $(`btn-mode-${difficulty}`).addEventListener('click', () => {
        this.ctl.audio.play('ui');
        this.selectedDifficulty = difficulty;
        this.renderMenu();
      });
    }
    $('btn-continue').addEventListener('click', () => {
      this.ctl.audio.play('ui');
      this.ctl.resumeRun();
    });
    $('btn-endless').addEventListener('click', () => {
      this.ctl.audio.play('ui');
      const start = () => this.ctl.openEndless(this.selectedChar || (this.ctl.getSave().unlocks.characters[0] || 'shanpo'));
      if (this.ctl.hasUnfinished()) this.confirmAction('开启无尽模式', '上一局尚未完成。开启无尽模式会覆盖旧局存档，确定继续吗？', start);
      else start();
    });
    $('btn-trials').addEventListener('click', () => {
      this.ctl.audio.play('ui');
      this.renderTrials();
      this.show('trials');
    });
    $('btn-inscriptions').addEventListener('click', () => {
      this.ctl.audio.play('ui');
      this.renderInscriptions();
      this.show('inscriptions');
    });
    $('btn-codex').addEventListener('click', () => {
      this.ctl.audio.play('ui');
      this.renderCodex();
      this.show('codex');
    });
    $('btn-settings').addEventListener('click', () => {
      this.ctl.audio.play('ui');
      this.renderSettings();
      this.show('settings');
    });
    $('btn-about').addEventListener('click', () => {
      this.ctl.audio.play('ui');
      this.renderAbout();
      this.show('about');
    });
    $('btn-pause').addEventListener('click', () => {
      this.ctl.audio.play('ui');
      this.ctl.pause();
      this.renderPause(this.ctl.world());
      this.show('pause');
    });
    $('btn-recipe').addEventListener('click', () => {
      this.ctl.audio.play('ui');
      this.ctl.pause();
      this.renderPause(this.ctl.world());
      this.show('pause');
      $('pause-recipes')?.scrollIntoView({ block: 'start' });
    });
    $('btn-resume').addEventListener('click', () => {
      this.ctl.audio.play('ui');
      this.show('hud');
      this.ctl.resume();
    });
    $('btn-savequit').addEventListener('click', () => {
      this.ctl.audio.play('ui');
      const ok = this.ctl.saveAndQuit();
      this.renderMenu();
      this.show('menu');
      if (!ok) this.toast('保存失败（本机存储不可用），本局已放弃。');
    });
    $('btn-quit').addEventListener('click', () => {
      this.ctl.audio.play('ui');
      this.ctl.quitRun();
      this.renderMenu();
      this.show('menu');
    });
    $('btn-settle-endless').addEventListener('click', () => {
      this.confirmAction('主动结算无尽', '结算本局并领取已获得的奖励？确认后不能继续这一局。', () => {
        this.ctl.settleEndless();
      });
    });
    $('btn-refresh').addEventListener('click', () => {
      this.ctl.audio.play('ui');
      this.ctl.refreshCards();
    });
    $('btn-confirm-card').addEventListener('click', () => this.confirmCard());
    $('btn-again').addEventListener('click', () => {
      this.ctl.audio.play('ui');
      this.ctl.restart();
    });
    $('btn-endless2').addEventListener('click', () => {
      this.ctl.audio.play('ui');
      this.ctl.continueEndless();
    });
    $('btn-tomenu').addEventListener('click', () => {
      this.ctl.audio.play('ui');
      this.ctl.toMenu();
    });
    $('btn-wipe').addEventListener('click', () => {
      this.confirmAction('清空本机进度', '最高分、图鉴、试炼、解锁和命篆都会清空。确定吗？', () => {
        this.ctl.wipe();
        this.renderSettings();
        this.renderMenu();
      });
    });
  }

  // ---------------- 主菜单 ----------------

  renderMenu() {
    const save = this.ctl.getSave();
    const chars = CHARACTERS.filter((c) => save.unlocks.characters.includes(c.id));
    if (!this.selectedChar || !save.unlocks.characters.includes(this.selectedChar)) {
      this.selectedChar = chars[0] ? chars[0].id : 'shanpo';
    }
    const list = $('char-list');
    list.innerHTML = '';
    for (const c of chars) {
      const ser = SERIES[c.series];
      const div = document.createElement('button');
      div.className = 'char-card' + (c.id === this.selectedChar ? ' selected' : '');
      div.style.setProperty('--series', ser.color);
      div.style.setProperty('--accent', ser.accent);
      div.innerHTML = `
        <div class="char-head"><span class="dot"></span><b>${c.cn}</b><span class="series-tag">${ser.cn}</span></div>
        <div class="char-blurb">${c.blurb || ''}</div>`;
      div.addEventListener('click', () => {
        this.ctl.audio.play('ui');
        this.selectedChar = c.id;
        this.renderMenu();
      });
      list.appendChild(div);
    }

    const hs = save.highScore;
    const selected = CHARACTER_BY_ID[this.selectedChar];
    const selectedSeries = SERIES[selected.series];
    const art = $('selected-char-art');
    art.src = `assets/sprites/char_${selected.id}.png`;
    art.alt = `${selected.cn}立绘`;
    $('selected-char-name').textContent = `${selected.cn} · ${selectedSeries.cn}`;
    $('selected-char-seal').textContent = selected.cn;
    const weapon = WEAPON_BY_ID[selected.weapon];
    const passive = PASSIVE_BY_ID[selected.passive];
    $('selected-char-info').innerHTML = `<span class="starter-line"><b>武器 · ${weapon?.cn || selected.weapon}</b>${weapon?.blurb || ''}</span>
      <span class="starter-line"><b>被动 · ${passive?.cn || selected.passive}</b>${passive?.desc || ''}</span>`;
    const hero = document.querySelector('.menu-hero');
    setSeriesBackdrop(hero, selected.series, !!hero.dataset.series);
    if (!hs.won) this.selectedDifficulty = 'normal';
    const normalMode = $('btn-mode-normal');
    const hardMode = $('btn-mode-hard');
    normalMode.classList.toggle('selected', this.selectedDifficulty === 'normal');
    hardMode.classList.toggle('selected', this.selectedDifficulty === 'hard');
    normalMode.setAttribute('aria-pressed', String(this.selectedDifficulty === 'normal'));
    hardMode.setAttribute('aria-pressed', String(this.selectedDifficulty === 'hard'));
    hardMode.disabled = !hs.won;
    hardMode.textContent = hs.won ? '困难 · 相柳后挑战烛九阴' : '困难 · 通关普通后解锁';
    $('btn-start').textContent = this.selectedDifficulty === 'hard' ? '开始困难模式' : '开始普通模式';
    $('highscore').innerHTML = hs.kills
      ? `<div>最高击杀 <b>${hs.kills}</b>　最长存活 <b>${fmtTime(save.records.maxTimeMs)}</b>　最高等级 <b>Lv${save.records.maxLevel}</b>${hs.won ? '　<span class="won">已通关</span>' : ''}</div>
         <div class="muted small">累计击杀 ${save.counters.killsTotal}　普通通关 ${save.counters.winsByDifficulty?.normal || 0}　困难通关 ${save.counters.winsByDifficulty?.hard || 0}</div>`
      : '<div class="muted">还没有记录。第一局只要活过 30 秒就会写进来。</div>';

    $('btn-continue').hidden = !this.ctl.hasUnfinished();
    $('btn-endless').hidden = !hs.won;
  }

  // ---------------- 暂停：本局已获得道具 ----------------

  /** 暂停界面：把本局已拿到的武器/被动、以及血统配方的达成情况摊开 */
  renderPause(world) {
    const box = $('pause-loadout');
    if (!box) return;
    if (!world) {
      box.innerHTML = '';
      return;
    }
    $('btn-settle-endless').hidden = !world.endless;
    const weaponItems = world.slots.weapons
      .map((w) => {
        const def = WEAPON_BY_ID[w.id];
        const sup = w.superId ? FUSION_BY_ID[w.superId] : null;
        const ser = SERIES[(def && def.series) || 'shan'];
        const name = sup ? `${sup.cn}` : def ? def.cn : w.id;
        const sub = sup ? `${def ? def.cn : ''} Lv${w.level}` : `Lv${w.level}`;
        return `<span class="loadout-item${sup ? ' is-super' : ''}" style="--series:${ser.color}">
          <img alt="" src="${iconDataUrl(sup ? 'icon_super' : 'icon_' + w.id)}">
          <span class="nm">${name}</span><span class="lv">${sub}</span></span>`;
      })
      .join('');
    const weaponEmpty = Array.from({ length: Math.max(0, SLOT_WEAPONS - world.slots.weapons.length) }, () => '<span class="loadout-slot-empty"></span>').join('');

    const passiveItems = world.slots.passives
      .map((pid) => {
        const p = PASSIVE_BY_ID[pid];
        const ser = SERIES[(p && p.series) || 'shan'];
        const lv = (world.passiveLevels && world.passiveLevels[pid]) || 1;
        return `<span class="loadout-item" style="--series:${ser.color}">
          <img alt="" src="${iconDataUrl(passiveIconSlot(pid))}">
          <span class="nm">${p ? p.cn : pid}</span><span class="lv">Lv${lv}${lv >= PASSIVE_MAX_LEVEL ? ' 满' : ''}</span></span>`;
      })
      .join('');
    const passiveEmpty = Array.from({ length: Math.max(0, SLOT_PASSIVES - world.slots.passives.length) }, () => '<span class="loadout-slot-empty"></span>').join('');

    // 血统配方进度：只有"本系武器"的配方才可能达成
    const rows = [];
    for (const f of FUSIONS) {
      const slot = world.slots.weapons.find((w) => w.id === f.weapon);
      if (!slot) continue;
      const hasPassive = world.slots.passives.includes(f.passive);
      const wDef = WEAPON_BY_ID[f.weapon];
      const maxed = slot.level >= WEAPON_MAX_LEVEL;
      let text;
      if (slot.superId === f.id) text = `<b>${f.cn}</b> 已觉醒`;
      else if (maxed && hasPassive) text = `<b>${f.cn}</b> 条件已满足（即将觉醒）`;
      else text = `<b>${f.cn}</b>：${wDef ? wDef.cn : f.weapon} Lv${slot.level}/${WEAPON_MAX_LEVEL}${maxed ? '（已满）' : `（还差 ${WEAPON_MAX_LEVEL - slot.level} 级）`} · ${passiveName(f.passive)}${hasPassive ? '（已有）' : '（未有）'}`;
      const missing = (WEAPON_MAX_LEVEL - slot.level) + (hasPassive ? 0 : 1);
      rows.push({ missing, html: `<div class="fusion-line${missing === 0 ? ' ready' : missing <= 2 ? ' near' : ''}">${text}</div>` });
    }
    rows.sort((a, b) => a.missing - b.missing);
    // 还没拿到的武器也能看到它的配方（告诉你下一步该攒什么）
    const notOwned = FUSIONS.filter((f) => {
      const weapon = WEAPON_BY_ID[f.weapon];
      return weapon && world.unlockedSeries.includes(f.series)
        && (weapon.unlock === 'initial' || weapon.unlock === 'pool' || world.unlocks.includes(weapon.id))
        && !world.slots.weapons.some((w) => w.id === f.weapon);
    });
    const hint = notOwned.length
      ? `<details class="recipe-more"><summary>其他可合体配方（${notOwned.length}）</summary>${notOwned.map((f) =>
        `<div class="fusion-line"><b>${f.cn}</b>：还需 ${weaponName(f.weapon)} Lv${WEAPON_MAX_LEVEL} · ${passiveName(f.passive)}${world.slots.passives.includes(f.passive) ? '（已有）' : '（未有）'}</div>`).join('')}</details>`
      : '';

    box.innerHTML = `
      <section class="loadout-sec">
        <h3>武器 <span class="count">${world.slots.weapons.length} / ${SLOT_WEAPONS}</span></h3>
        <div class="loadout-list">${weaponItems}${weaponEmpty}</div>
      </section>
      <section class="loadout-sec">
        <h3>被动 <span class="count">${world.slots.passives.length} / ${SLOT_PASSIVES}</span></h3>
        <div class="loadout-list">${passiveItems}${passiveEmpty}</div>
      </section>
      <section class="loadout-sec" id="pause-recipes">
        <h3>血统配方</h3>
        ${rows.map((r) => r.html).join('') || '<div class="muted-line">本局还没有可凑的配方</div>'}
        ${hint}
      </section>
      <div class="muted-line">存活 ${fmtTime(world.elapsedMs)}　等级 Lv${world.player.level}　击杀 ${world.runStats.kills}　难度档 ${world.runStats.maxTier + 1}</div>`;
  }

  // ---------------- 升级三选一 ----------------

  renderLevelUp(world) {
    this.currentCardChoices = world.cardChoices.slice();
    this.selectedCardIndex = -1;
    $('btn-confirm-card').disabled = true;
    const nearest = FUSIONS.map((f) => ({ f, slot: world.slots.weapons.find((w) => w.id === f.weapon) }))
      .filter((x) => x.slot && !x.slot.superId)
      .sort((a, b) => (WEAPON_MAX_LEVEL - a.slot.level + (world.slots.passives.includes(a.f.passive) ? 0 : 1))
        - (WEAPON_MAX_LEVEL - b.slot.level + (world.slots.passives.includes(b.f.passive) ? 0 : 1)))[0];
    $('levelup-sub').textContent = nearest
      ? `Lv${world.player.level} · 待选 ${world.pendingLevelUps}　血统目标 ${nearest.f.cn}：${weaponName(nearest.f.weapon)} ${nearest.slot.level}/${WEAPON_MAX_LEVEL}，${passiveName(nearest.f.passive)}${world.slots.passives.includes(nearest.f.passive) ? '已得' : '未得'}`
      : `等级 ${world.player.level}　剩余待选 ${world.pendingLevelUps}　血统配方见武器卡提示`;
    $('levelup-sub').classList.toggle('recipe-focus', !!nearest);
    // 同一轮里不会有两张相同的卡（不放回抽样），所以"能给的都拿完"时可能只有 1~2 张；
    // 这句说明文案跟着实际张数走，不要嘴上说"三张"而画面里只有两张。
    const hintEl = $('levelup-hint');
    if (hintEl) {
      hintEl.textContent =
        this.currentCardChoices.length >= 3
          ? '选中一项，再点击确定。'
          : `当前有 ${this.currentCardChoices.length} 项可选，选中后点击确定。`;
    }
    // 刷新按钮：跟着剩余次数走。用完了就禁用（而不是藏起来，让玩家知道这机制存在过）。
    const btn = $('btn-refresh');
    if (btn) {
      const left = world.refreshesLeft === undefined ? 0 : world.refreshesLeft;
      btn.textContent = left > 0 ? `刷新（剩 ${left} 次）` : '刷新（已用完）';
      btn.disabled = left <= 0;
    }
    const box = $('cards');
    box.innerHTML = '';
    for (let i = 0; i < this.currentCardChoices.length; i++) {
      const card = this.currentCardChoices[i];
      box.appendChild(this.cardEl(card, i, world));
    }
    if (this.renderLevelUpExtras) this.renderLevelUpExtras(world);
    this.showOverlay('levelup');
  }

  /**
   * 判断这张卡能不能"凑成血统配方"。
   * 两种情况：
   *  · 被动卡 → 若某把已持有武器已满级，且它的配方被动正是这张 → 直接触发
   *  · 武器升级卡 → 若这次升级刚好到满级，且配方被动已持有 → 直接触发
   * @returns {{kind:'now'|'missing', names:string[]}|null}
   */
  fuseOutlook(world, card) {
    if (!world) return null;
    const names = [];
    let progress = null;
    if (card.type === 'passive') {
      for (const f of FUSIONS) {
        if (f.passive !== card.passiveId) continue;
        const slot = world.slots.weapons.find((w) => w.id === f.weapon);
        if (!slot || slot.superId) continue;
        if (slot.level >= WEAPON_MAX_LEVEL) names.push(f.cn);
        else progress = `${f.cn}：被动齐备，${weaponName(f.weapon)} Lv${slot.level}/${WEAPON_MAX_LEVEL}`;
      }
    } else if (card.type === 'weapon-up') {
      const slot = world.slots.weapons.find((w) => w.id === card.weaponId);
      if (!slot) return null;
      const willMax = (card.level || slot.level + 1) >= WEAPON_MAX_LEVEL;
      for (const f of FUSIONS) {
        if (f.weapon !== card.weaponId) continue;
        if (slot.superId) continue;
        if (willMax && world.slots.passives.includes(f.passive)) names.push(f.cn);
        else if (willMax) progress = `${f.cn}：武器满级，还缺 ${passiveName(f.passive)}`;
        else progress = `${f.cn}：武器升至 Lv${card.level || slot.level + 1}/${WEAPON_MAX_LEVEL}${world.slots.passives.includes(f.passive) ? '，被动已得' : `，还缺 ${passiveName(f.passive)}`}`;
      }
    } else if (card.type === 'weapon-new') {
      // 新武器本身不触发配方，但可以提示它"值得凑"
      const f = FUSIONS.find((x) => x.weapon === card.weaponId);
      if (f) return { kind: 'missing', names: [], hint: `${f.cn}：新武器 Lv1/${WEAPON_MAX_LEVEL}，需 ${passiveName(f.passive)}` };
      return null;
    }
    if (names.length) return { kind: 'now', names };
    if (progress) return { kind: 'missing', names: [], hint: progress };
    return null;
  }

  cardEl(card, idx, world) {
    const div = document.createElement('div');
    div.className = 'card';
    const outlook = this.fuseOutlook(world, card);
    let title = '';
    let sub = '';
    let body = '';
    let series = 'shan';
    // 兜底：通用被动图标。具体道具都会在下面各自的分支里覆盖成自己的图标，
    // 只有"数值类兜底卡"这种本来就没有专属图的才留在这里（刻意的回退）。
    let icon = 'icon_passive';
    if (card.type === 'weapon-new' || card.type === 'weapon-up') {
      const w = WEAPON_BY_ID[card.weaponId];
      if (!w) return div;
      series = w.series;
      icon = 'icon_' + w.id;
      title = w.cn;
      const lv = card.type === 'weapon-up' ? card.level : 1;
      sub = `${SERIES[w.series].cn} · ${WEAPON_KIND_CN[w.kind] || '武器'} · Lv${lv}`;
      const cur = card.type === 'weapon-up' ? levelStats(w, card.level) : levelStats(w, 1);
      const prev = card.type === 'weapon-up' ? levelStats(w, card.level - 1) : null;
      body = `<p class="card-desc">${w.blurb || ''}</p>`;
      if (prev) {
        body += `<ul class="delta">${deltaList(prev, cur)}</ul>`;
      } else {
        body += `<ul class="delta"><li>伤害 ${Math.round(cur.damage)}</li><li>冷却 ${cur.cd}s</li></ul>`;
      }
      const f = FUSIONS.find((x) => x.weapon === w.id);
      if (f) body += `<p class="fusion-hint">血统：满级 + ${passiveName(f.passive)} → <b>${f.cn}</b></p>`;
    } else if (card.type === 'passive') {
      const p = PASSIVE_BY_ID[card.passiveId];
      if (!p) return div;
      series = p.series;
      icon = passiveIconSlot(p.id);
      title = p.cn;
      sub = `${SERIES[p.series].cn} · 被动 · Lv1`;
      body = `<p class="card-desc">${p.desc}</p><p class="muted small">修改通道：${CHANNEL_BY_ID[p.channel] ? CHANNEL_BY_ID[p.channel].cn : p.channel}（可继续升级）</p>`;
      const f = FUSIONS.find((x) => x.passive === p.id);
      if (f) body += `<p class="fusion-hint">血统：${weaponName(f.weapon)} 满级 + 本件 → <b>${f.cn}</b></p>`;
    } else if (card.type === 'passive-up') {
      const p = PASSIVE_BY_ID[card.passiveId];
      if (!p) return div;
      const lv = card.level || 2;
      series = p.series;
      icon = passiveIconSlot(p.id);
      title = p.cn;
      sub = `${SERIES[p.series].cn} · 被动 · Lv${lv} / ${PASSIVE_MAX_LEVEL}`;
      const step = PLAYER_BASE.passiveLevelStep || 0.6;
      const before = p.value * (1 + (lv - 2) * step);
      const after = p.value * (1 + (lv - 1) * step);
      body = `<p class="card-desc">${p.desc}</p>${channelDeltaLine(p.channel, before, after)}`;
    } else if (card.type === 'stat') {
      series = 'huang';
      // 数值类兜底卡没有专属图，用通用被动图标（刻意的回退分支）
      icon = 'icon_passive';
      title = card.cn;
      sub = '通用强化 · 已全部升满';
      body = `<p class="card-desc">所有武器与被动都已满级，升级转为永久数值强化。</p>${channelDeltaLine(
        card.channel,
        0,
        card.value,
        card.cn,
      )}`;
    } else {
      title = '无可用提升';
      sub = '内容已全部拿完';
      body = '<p class="card-desc">武器全满级、槽位全满。本次升级作废，继续打下去。</p>';
    }
    div.style.setProperty('--series', SERIES[series].color);
    div.style.setProperty('--accent', SERIES[series].accent);
    if (outlook && outlook.kind === 'now') div.classList.add('can-fuse');
    const badge =
      outlook && outlook.kind === 'now'
        ? `<div class="card-fuse-badge">选它 → 立刻觉醒 ${outlook.names.join('、')}</div>`
        : outlook && outlook.kind === 'missing'
          ? `<div class="card-fuse-badge" style="background:rgba(240,179,87,0.25);color:#ffe08a">${outlook.hint ? outlook.hint : '离觉醒更近一步'}</div>`
          : '';
    div.innerHTML = `
      <svg class="card-motif" viewBox="0 0 600 180" preserveAspectRatio="xMidYMax slice" aria-hidden="true"><path opacity=".45" d="${motifPath(MOTIF_SHAPES[series].back, MOTIF_SHAPES[series].smooth)}"/><path d="${motifPath(MOTIF_SHAPES[series].front, MOTIF_SHAPES[series].smooth)}"/><use href="#motif-mark-${series}"/></svg>
      <div class="card-top">
        <span class="card-seal" lang="zh-Hant" aria-label="${SERIES[series].cn}">${SERIES_SEALS[series]}</span>
        <span class="card-idx">${idx + 1}</span>
      </div>
      <div class="card-icon"><img alt="" src="${iconDataUrl(icon)}"></div>
      <h3>${title}</h3>
      <div class="card-sub">${sub}</div>
      ${badge}
      <div class="card-body">${body}</div>
      <span class="card-select">选择此项</span>`;
    div.setAttribute('role', 'button');
    div.tabIndex = 0;
    div.setAttribute('aria-label', `选择${title}`);
    div.setAttribute('aria-pressed', 'false');
    div.addEventListener('click', () => {
      this.selectCard(idx);
    });
    div.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter' && event.key !== ' ') return;
      event.preventDefault();
      div.click();
    });
    return div;
  }

  selectCard(index) {
    if (this.el('levelup').hidden || !this.currentCardChoices[index]) return;
    const changed = this.selectedCardIndex !== index;
    this.selectedCardIndex = index;
    $('cards').querySelectorAll('.card').forEach((card, i) => {
      card.classList.toggle('selected', i === index);
      card.setAttribute('aria-pressed', String(i === index));
      card.querySelector('.card-select').textContent = i === index ? '已选中' : '选择此项';
    });
    $('btn-confirm-card').disabled = false;
    if (changed) this.ctl.audio.play('ui');
  }

  confirmCard() {
    const card = this.currentCardChoices[this.selectedCardIndex];
    if (this.el('levelup').hidden || !card) return;
    // 先消费 UI 选择，防止连点把同一张卡应用到下一次升级。
    this.selectedCardIndex = -1;
    $('btn-confirm-card').disabled = true;
    this.ctl.audio.play('ui');
    this.ctl.takeCard(card);
  }

  hideLevelUp() {
    const el = this.el('levelup');
    if (el) el.hidden = true;
  }

  // ---------------- 结算 ----------------

  renderResult(world, extra = {}) {
    const r = world.finish();
    const won = r.outcome === 'win';
    const hard = r.difficulty === 'hard';
    const endless = !!r.endless;
    $('result-summary').dataset.outcome = won ? 'win' : 'dead';
    $('result-title').textContent = endless ? '无尽结算' : won ? (hard ? '困难通关' : '普通通关') : (hard ? '困难挑战结束' : '这一局结束了');
    const slots = world.slots.weapons
      .map((w) => {
        const def = WEAPON_BY_ID[w.id];
        const sup = w.superId ? FUSION_BY_ID[w.superId] : null;
        return `<li>${def ? def.cn : w.id} Lv${w.level}${sup ? ` → <b class="super">${sup.cn}</b>` : ''}</li>`;
      })
      .join('');
    const passives = world.slots.passives
      .map((pid) => {
        const lv = (world.passiveLevels && world.passiveLevels[pid]) || 1;
        return `<li>${passiveName(pid)} Lv${lv}</li>`;
      })
      .join('');
    $('result-summary').innerHTML = `
      <div class="result-verdict">${endless ? '无尽征途结束' : won ? '本局通关' : '本局结束'}<span>${endless ? '无尽模式' : hard ? '困难模式' : '普通模式'}</span></div>
      ${extra.inscriptionReward ? `<p class="inscription-reward">灵蕴：通用 +${extra.inscriptionReward.common}　${SERIES[extra.inscriptionReward.seriesId]?.cn || '本系'} +${extra.inscriptionReward.series}（存活 +${extra.inscriptionReward.timeReward}${extra.inscriptionReward.killReward ? `、击杀 +${extra.inscriptionReward.killReward}` : ''}${extra.inscriptionReward.winBonus ? `、通关 +${extra.inscriptionReward.winBonus}` : ''}）　归篆符 ${extra.inscriptionReward.resetTickets}/3（${extra.inscriptionReward.resetProgress}/3 格）</p>` : '<p class="muted small">本局无灵蕴奖励。</p>'}
      ${extra.highScoreBeaten ? '<p class="won">刷新了本机最高击杀记录。</p>' : ''}
      ${extra.hardUnlocked ? '<p class="won">困难模式已解锁，可在主菜单选择。</p>' : ''}`;
    $('result-body').innerHTML = `
      <h3>本局统计</h3>
      <div class="result-grid">
        <div><span class="k">模式</span><span class="v">${endless ? '无尽' : hard ? '困难' : '普通'}</span></div>
        <div><span class="k">存活</span><span class="v">${fmtTime(r.elapsedMs)}</span></div>
        <div><span class="k">击杀</span><span class="v">${r.kills}</span></div>
        ${endless ? `<div><span class="k">击败 Boss</span><span class="v">${r.endlessCycle}</span></div>` : ''}
        <div><span class="k">等级</span><span class="v">Lv${r.level}</span></div>
        <div><span class="k">难度档</span><span class="v">${r.maxTier + 1}</span></div>
        <div><span class="k">超武</span><span class="v">${r.superCount}</span></div>
        <div><span class="k">角色</span><span class="v">${CHARACTER_BY_ID[r.characterId] ? CHARACTER_BY_ID[r.characterId].cn : r.characterId}</span></div>
      </div>
      <h3>本局装备</h3>
      <div class="result-loadout">
        <div><h4>武器</h4><ul>${slots || '<li>—</li>'}</ul></div>
        <div><h4>被动</h4><ul>${passives || '<li>—</li>'}</ul></div>
      </div>
      <p class="muted small">${endless ? (won ? '首次击败相柳已计入通关，本局奖励已结算。' : '本局按存活与击杀结算，不重复计入通关。') : won ? (hard ? '击败相柳与烛九阴，困难挑战完成。' : '击杀相柳即通关。现在可以选择继续打无尽模式（每 2 分钟 +1 难度档）。') : '差一点就赢了。下一局可以试试提前规划血统配方。'}</p>`;
    const tbox = $('result-trials');
    tbox.innerHTML = '';
    for (const t of extra.newTrials || []) {
      const d = document.createElement('div');
      d.className = 'trial-unlock';
      d.innerHTML = `<b>试炼达成：${t.name}</b><span>${t.rewardText}</span>`;
      tbox.appendChild(d);
    }
    $('btn-endless2').hidden = !won || hard || endless;
    this.showOverlay('result');
  }

  // ---------------- 试炼 ----------------

  renderInscriptions() {
    const save = this.ctl.getSave();
    const state = save.inscriptions;
    const scope = this.selectedInscriptionTab;
    const common = scope === 'common';
    const locked = !common && !save.unlocks.series.includes(scope);
    const balance = common ? state.balance.common : state.balance.series[scope];
    const levels = common ? state.common : state.series[scope];
    const nodes = common ? COMMON_NODES : SERIES_NODES;
    if (!nodes.some((node) => node.id === this.selectedInscriptionNode)) this.selectedInscriptionNode = nodes[0].id;
    const box = $('inscriptions-body');
    const valueText = (node, level) => {
      if (node.id === 'weapon') return `${level ? node.values[level - 1] : 1.8} 倍权重`;
      const data = node.id === 'trait' ? SERIES_TRAITS[scope] : node;
      return `+${level ? data.values[level - 1] : 0}${data.unit}`;
    };
    const trial = TRIALS.find((t) => t.reward.kind === 'series' && t.reward.id === scope);
    const tabs = [{ id: 'common', cn: '通用' }, ...SERIES_IDS.map((id) => ({ id, cn: SERIES[id].cn }))];
    const nodeCards = nodes.map((node) => {
      const level = levels[node.id];
      const cn = node.id === 'trait' ? SERIES_TRAITS[scope].cn : node.cn;
      return `<button type="button" class="inscription-node ${this.selectedInscriptionNode === node.id ? 'selected' : ''}" data-inscription-node="${node.id}" aria-pressed="${this.selectedInscriptionNode === node.id}">
        <span class="inscription-node-mark">${cn.slice(0, 1)}</span><b>${cn}</b><span>${level}/${node.costs.length} 级</span>
      </button>`;
    }).join('');
    const activeNode = nodes.find((node) => node.id === this.selectedInscriptionNode);
    const activeLevel = levels[activeNode.id];
    const activeCost = activeNode.costs[activeLevel];
    const activeName = activeNode.id === 'trait' ? SERIES_TRAITS[scope].cn : activeNode.cn;
    const refund = inscriptionRefund(state, scope);
    const targets = common || locked ? [] : save.unlocks.series.filter((id) => id !== scope && !seriesMaxed(state, id) && state.balance.series[id] < SERIES_BALANCE_CAP);
    const previousBackdrop = box.querySelector('.inscription-tree-wrap .series-backdrop');
    previousBackdrop?.remove();
    box.innerHTML = `
      <div class="inscription-summary">通用灵蕴 <b>${state.balance.common}</b>　归篆符 <b>${state.resetTickets}/3</b>　通关进度 <b>${state.resetProgress}/3</b></div>
      <div class="inscription-tabs">${tabs.map((t) => `<button type="button" data-inscription-tab="${t.id}" class="${scope === t.id ? 'selected' : ''}">${t.cn}${t.id !== 'common' && !save.unlocks.series.includes(t.id) ? ' · 锁' : ''}</button>`).join('')}</div>
      <div class="inscription-workspace">
        <div class="inscription-tree-wrap">
          <div class="inscription-summary">${common ? '通用' : SERIES[scope].cn}灵蕴 <b>${balance}</b>${common ? '' : ` / ${SERIES_BALANCE_CAP}（重置退还可暂超上限）`}</div>
          ${locked ? `<p class="muted">完成试炼后可培养：${trial ? trial.hint : '尚未解锁'}</p>` : ''}
          <div class="inscription-nodes">${nodeCards}</div>
          <p class="muted small">各节点独立培养，无前置条件。</p>
        </div>
        <aside class="inscription-detail" aria-label="命篆详情">
          <span class="menu-eyebrow">命篆详情</span><h3>${activeName}</h3>
          <p>${activeCost === undefined ? valueText(activeNode, activeLevel) : `${valueText(activeNode, activeLevel)} → ${valueText(activeNode, activeLevel + 1)}`}</p>
          <p class="muted">当前 ${activeLevel}/${activeNode.costs.length} 级${activeCost === undefined ? ' · 已满级' : ` · 下级消耗 ${activeCost} 灵蕴`}</p>
          <button type="button" data-inscription-buy="${activeNode.id}" ${locked || activeCost === undefined || balance < activeCost ? 'disabled' : ''}>${activeCost === undefined ? '已满级' : `提升此篆 · ${activeCost} 灵蕴`}</button>
          <div class="inscription-actions"><button type="button" id="inscription-reset" ${locked || !refund || !state.resetTickets ? 'disabled' : ''}>重置本页 · 退还 ${refund} 灵蕴 · 消耗 1 张归篆符</button></div>
        </aside>
      </div>
      ${!common && !locked ? `<div class="inscription-convert">
        <b>转换本系灵蕴</b><span class="muted small">　2 点本系 → 1 点目标系，仅限已解锁神系</span>
        <div class="inscription-convert-controls">
          <select id="inscription-target" aria-label="目标神系">${targets.map((id) => `<option value="${id}">${SERIES[id].cn}（${state.balance.series[id]}/${SERIES_BALANCE_CAP}）</option>`).join('')}</select>
          <input id="inscription-amount" type="number" min="1" step="1" value="1" aria-label="获得的目标系灵蕴数量">
          <button type="button" id="inscription-convert" ${targets.length && balance >= 2 ? '' : 'disabled'}>转换</button>
        </div>
      </div>` : ''}`;
    const tree = box.querySelector('.inscription-tree-wrap');
    if (previousBackdrop) tree.prepend(previousBackdrop);
    else tree.insertAdjacentHTML('afterbegin', seriesBackdropMarkup(scope));
    if (previousBackdrop) tree.offsetWidth;
    setSeriesBackdrop(tree, scope, !!previousBackdrop);
    box.dataset.seriesScope = scope;
    box.querySelectorAll('[data-inscription-tab]').forEach((button) => button.addEventListener('click', () => {
      this.selectedInscriptionTab = button.dataset.inscriptionTab;
      this.selectedInscriptionNode = this.selectedInscriptionTab === 'common' ? 'maxHp' : 'weapon';
      this.renderInscriptions();
    }));
    box.querySelectorAll('[data-inscription-node]').forEach((button) => button.addEventListener('click', () => {
      this.selectedInscriptionNode = button.dataset.inscriptionNode;
      this.renderInscriptions();
      box.querySelector(`[data-inscription-node="${this.selectedInscriptionNode}"]`)?.focus();
    }));
    box.querySelectorAll('[data-inscription-buy]').forEach((button) => button.addEventListener('click', () => {
      const id = button.dataset.inscriptionBuy;
      const node = nodes.find((n) => n.id === id);
      const cost = node.costs[levels[id]];
      this.confirmAction('提升命篆', `消耗 ${cost} 点${common ? '通用' : SERIES[scope].cn}灵蕴，提升「${id === 'trait' ? SERIES_TRAITS[scope].cn : node.cn}」至 ${levels[id] + 1} 级？\n${valueText(node, levels[id])} → ${valueText(node, levels[id] + 1)}`, () => {
        if (!this.ctl.purchaseInscription(scope, id)) this.toast('灵蕴不足或该命篆已满级。');
        this.renderInscriptions();
      });
    }));
    $('inscription-reset').addEventListener('click', () => {
      this.confirmAction('重置命篆', `消耗 1 张归篆符，重置${common ? '通用' : SERIES[scope].cn}命篆并退还 ${refund} 点灵蕴？`, () => {
        if (!this.ctl.resetInscriptions(scope)) this.toast('无法重置当前命篆。');
        this.renderInscriptions();
      });
    });
    const convert = $('inscription-convert');
    if (convert) convert.addEventListener('click', () => {
      const target = $('inscription-target').value;
      const amount = Number($('inscription-amount').value);
      if (!Number.isSafeInteger(amount) || amount < 1) return this.toast('请输入正整数。');
      this.confirmAction('转换灵蕴', `消耗 ${amount * 2} 点${SERIES[scope].cn}灵蕴，获得 ${amount} 点${SERIES[target].cn}灵蕴？转换后不能撤销。`, () => {
        if (!this.ctl.convertInscriptions(scope, target, amount)) this.toast('灵蕴不足、目标已满或目标库存将超过上限。');
        this.renderInscriptions();
      });
    });
  }

  renderTrials() {
    const save = this.ctl.getSave();
    const box = $('trials-body');
    box.innerHTML = '';
    const orderedTrials = SERIES_IDS.flatMap((sid) => TRIALS.filter((trial) => (trial.series || trial.id) === sid));
    for (const t of orderedTrials) {
      const ser = SERIES[t.series || t.id];
      const pr = trialProgress(save, t);
      const done = isTrialDone(save, t);
      const pct = Math.min(100, Math.round((pr.cur / pr.goal) * 100));
      const div = document.createElement('div');
      div.className = 'trial' + (done ? ' done' : '');
      div.dataset.trialId = t.id;
      div.dataset.seriesMark = SERIES_SEALS[ser.id].slice(0, 1);
      div.style.setProperty('--series', ser.color);
      div.style.setProperty('--accent', ser.accent);
      div.innerHTML = `
        <div class="trial-head">
          <span class="series-tag">${ser.cn}</span>
          <b>${t.name}</b>
          <span class="trial-state">${done ? '已完成' : pr.cur + ' / ' + pr.goal}</span>
        </div>
        <div class="bar"><i style="width:${pct}%"></i></div>
        <div class="trial-foot">
          <span>条件：${t.hint}</span>
          <span class="reward">奖励：${t.rewardText}</span>
        </div>`;
      box.appendChild(div);
    }
  }

  // ---------------- 图鉴 ----------------

  renderCodex() {
    const save = this.ctl.getSave();
    const data = codexBySeries(save);
    const box = $('codex-body');
    box.innerHTML = '';
    for (const sid of ['shan', 'hai', 'huang', 'tian', 'ling', 'kun']) {
      const vol = data[sid];
      const locked = !save.unlocks.series.includes(sid);
      const sec = document.createElement('section');
      sec.className = 'codex-vol' + (locked ? ' locked' : '');
      sec.dataset.seriesMark = SERIES_SEALS[sid].slice(0, 1);
      sec.style.setProperty('--series', vol.series.color);
      sec.style.setProperty('--accent', vol.series.accent);
      const head = `<h3><span class="series-tag">${vol.series.cn}</span> ${vol.series.title}${locked ? '<span class="muted small">（未解锁）</span>' : ''}</h3>`;
      if (locked) {
        sec.innerHTML = head + '<p class="muted">通过试炼解锁这一卷。</p>';
        box.appendChild(sec);
        continue;
      }
      const weapons = BATCH1_WEAPONS.filter((w) => w.series === sid)
        .map((w) => {
          const seen = !!save.codex[w.id];
          return `<li class="${seen ? 'seen' : 'unseen'}"><b>${seen ? w.cn : '？？？'}</b><span>${seen ? (WEAPON_KIND_CN[w.kind] || '') + ' · 初始 Lv1 伤害 ' + Math.round(levelStats(w, 1).damage) : '还没见过'}</span></li>`;
        })
        .join('');
      const passives = BATCH1_PASSIVES.filter((p) => p.series === sid)
        .map((p) => {
          const seen = !!save.codex[p.id];
          return `<li class="${seen ? 'seen' : 'unseen'}"><b>${seen ? p.cn : '？？？'}</b><span>${seen ? p.desc : '还没见过'}</span></li>`;
        })
        .join('');
      const fusions = FUSIONS.filter((f) => f.series === sid)
        .map((f) => {
          // 配方的"揭示"条件：它涉及的那把武器和那件被动都见过。
          // 否则就是直接把答案告诉玩家——图鉴的价值在于"发现"。
          const seenWeapon = !!save.codex[f.weapon];
          const seenPassive = !!save.codex[f.passive];
          const revealed = !!save.codex[f.id] || (seenWeapon && seenPassive);
          if (!revealed) {
            return `<li class="unseen"><b>？？？</b><span>继续探索以揭示这条血统</span></li>`;
          }
          return `<li class="seen"><b>${f.cn}</b><span>${weaponName(f.weapon)} 满级 + ${passiveName(f.passive)} → ${f.effect}</span></li>`;
        })
        .join('');
      sec.innerHTML = `${head}
        <div class="codex-cols">
          <div><h4>武器</h4><ul>${weapons}</ul></div>
          <div><h4>被动</h4><ul>${passives}</ul></div>
          <div><h4>血统配方</h4><ul>${fusions}</ul></div>
        </div>`;
      box.appendChild(sec);
    }
  }

  // ---------------- 设置 ----------------

  renderSettings() {
    const s = this.ctl.getSettings();
    const save = this.ctl.getSave();
    const allUnlocked = ['shan', 'hai', 'huang', 'tian', 'ling', 'kun'].every((id) => save.unlocks.series.includes(id));
    const box = $('settings-body');
    const row = (label, id, checked, hint = '') => `
      <label class="set-row"><span>${label}${hint ? `<em>${hint}</em>` : ''}</span>
      <input type="checkbox" id="${id}" ${checked ? 'checked' : ''}></label>`;
    box.innerHTML = `
      ${row('静音', 'set-muted', s.muted, '地铁上玩的时候用')}
      <label class="set-row"><span>音量<em>${Math.round(s.volume * 100)}%</em></span>
        <input type="range" id="set-volume" min="0" max="100" value="${Math.round(s.volume * 100)}"></label>
      <label class="set-row"><span>画质<em>低端机建议自动降档</em></span>
        <select id="set-quality">
          <option value="auto"${s.quality === 'auto' ? ' selected' : ''}>自动</option>
          <option value="high"${s.quality === 'high' ? ' selected' : ''}>高（开特效）</option>
          <option value="low"${s.quality === 'low' ? ' selected' : ''}>低（关特效）</option>
        </select></label>
      ${row('打击特效', 'set-effects', s.effects, '粒子与光效')}
      ${row('屏幕震动', 'set-shake', s.shake)}
      ${row('伤害数字', 'set-damageNumbers', s.damageNumbers, '关掉能明显省性能')}
      ${row('开发模式：占位图标注槽位 id', 'set-devLabels', s.devLabels, '正式美术替换时用')}
      ${row('开发模式：解锁全部神系与角色（跳过试炼）', 'set-unlockAll', allUnlocked, '只用来检查系统层；后三系内容仍是骨架')}
      <div class="muted small">音频解锁需要一次用户手势；切后台再回前台会自动重新恢复。</div>`;
    const upd = (patch) => {
      this.ctl.setSettings(patch);
      this.renderSettings();
    };
    $('set-muted').addEventListener('change', (e) => {
      this.ctl.audio.setMuted(e.target.checked);
      upd({ muted: e.target.checked });
    });
    $('set-volume').addEventListener('input', (e) => {
      const v = Number(e.target.value) / 100;
      this.ctl.audio.volume = v;
      if (this.ctl.audio.master) this.ctl.audio.master.gain.value = this.ctl.audio.muted ? 0 : v;
      upd({ volume: v });
    });
    $('set-quality').addEventListener('change', (e) => upd({ quality: e.target.value }));
    $('set-effects').addEventListener('change', (e) => upd({ effects: e.target.checked }));
    $('set-shake').addEventListener('change', (e) => upd({ shake: e.target.checked }));
    $('set-damageNumbers').addEventListener('change', (e) => upd({ damageNumbers: e.target.checked }));
    $('set-devLabels').addEventListener('change', (e) => upd({ devLabels: e.target.checked }));
    $('set-unlockAll').addEventListener('change', (e) => {
      this.ctl.setUnlockAll(e.target.checked);
      this.renderSettings();
    });
  }

  // ---------------- 关于 / 许可 ----------------

  renderAbout() {
    const env = guessEnvironment();
    const stats = placeholderStats();
    const counts = {};
    for (const s of SLOTS) counts[s.category] = (counts[s.category] || 0) + 1;
    const catRows = Object.keys(counts)
      .map((k) => `<li>${k}：${counts[k]} 个槽位</li>`)
      .join('');
    $('about-body').innerHTML = `
      <p>《山海拾遗》v${VERSION} —— 单页网页游戏（HTML + Canvas 2D + 原生 JavaScript），零依赖、零构建期框架。</p>
      <h3>运行环境</h3>
      <ul>
        <li>用户代理：<code>${escapeHtml(env.ua || '未知')}</code></li>
        <li>Android 版本：${env.androidVersion || '未知'}　Chrome 内核：${env.chromeVersion || '未知'}${env.isWebView ? '（WebView）' : ''}</li>
      </ul>
      <h3>素材许可</h3>
      <p>游戏使用本项目自绘的像素精灵与程序生成的 Canvas 2D 图形，音效由 WebAudio 合成。</p>
      <p>槽位总数 ${stats.total}：程序生成 ${stats.generated}，已替换为正式文件 ${stats.supplied}。</p>
      <ul>${catRows}</ul>
      <p>已替换的精灵由本项目绘制；如后续使用第三方素材，会在此列出来源与许可信息。</p>
      <h3>字体</h3>
      <p>正文使用设备自带字体；小篆标题使用「全字庫說文解字」的标题字形子集。来源：数位发展部 CNS11643 中文标准交换码全字库网站。字体按 SIL Open Font License 1.1 授权，授权全文随应用保存在 <code>assets/fonts/OFL.txt</code>。</p>
      <h3>不联网声明</h3>
      <p>运行期间不发出任何网络请求：没有 SDK、没有云存档、没有排行榜、没有广告、没有内购、没有账号体系。</p>
      <h3>其他</h3>
      <ul>
        <li>隐私政策：<a href="#" id="link-privacy">查看本机隐私说明</a></li>
        <li>本机存档只保存在浏览器 localStorage 中，可以随时在「设置」里清空。</li>
      </ul>`;
    const link = $('link-privacy');
    if (link) {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        this.renderPrivacy();
        this.show('privacy');
      });
    }
  }

  renderPrivacy() {
    $('privacy-body').innerHTML = `
      <p>运营者：开水的工作室　更新日期：2026 年 10 月 12 日</p>
      <p>本政策适用于 Android 游戏《山海拾遗》（包名：com.wuqijiangye.shanhai）。游戏可离线运行，不要求注册或登录。请阅读以下说明，了解游戏如何处理数据。</p>
      <h3>一、我们处理哪些数据</h3>
      <p>游戏不主动收集、上传或共享你的姓名、手机号、身份信息、位置、通讯录等个人信息。游戏运行时不向我们的服务器发送网络请求，也不使用广告、统计、推送或崩溃上报服务。</p>
      <p>为了保存游玩进度，游戏仅在你的设备上保存最高分、累计击杀、图鉴、试炼与解锁进度、设置，以及未完成的一局。这些数据保存在应用内部 WebView 的本地存储中，不会同步到我们的服务器。</p>
      <h3>二、设备权限</h3>
      <p>Android 安装包声明了网络权限，用于 WebView 通过应用内部虚拟地址加载安装包中的本地页面和素材；这一加载过程由应用在设备内处理。游戏本体不向外部服务器请求游玩数据。游戏不申请位置、相机、麦克风或通讯录权限。</p>
      <h3>三、存储、删除与共享</h3>
      <p>本机进度在你使用游戏期间保存在设备上。你可以在游戏内“设置 → 清空本机进度”删除这些数据；卸载应用或清除应用数据也会删除本机进度。我们不会出售、共享或向第三方传输游戏进度。</p>
      <h3>四、未成年人</h3>
      <p>游戏不以收集未成年人个人信息为目的。未成年人应在监护人指导下使用游戏。通过第三方平台下载或游玩时，平台可能依据其自身隐私政策和未成年人保护规则处理账户及设备信息；请同时阅读相应平台的说明。</p>
      <h3>五、政策变更与联系</h3>
      <p>如果游戏的数据处理方式发生变化，我们会更新本政策和游戏内说明，并在更新时注明日期。如对隐私事项有疑问，请联系 3522249258@qq.com。</p>`;
  }

  toast(text) {
    const el = $('hud-hint');
    if (!el) return;
    el.textContent = text;
    el.hidden = false;
    clearTimeout(this._toastT);
    this._toastT = setTimeout(() => {
      el.hidden = true;
    }, 3200);
  }
}

// ---------------- 小工具 ----------------

function fmtTime(ms) {
  const s = Math.floor((ms || 0) / 1000);
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
}

function weaponName(id) {
  const w = WEAPON_BY_ID[id];
  return w ? w.cn : id;
}

function passiveName(id) {
  const p = PASSIVE_BY_ID[id];
  return p ? p.cn : id;
}

function deltaList(prev, cur) {
  const keys = ['damage', 'cd', 'count', 'radius', 'speed', 'size', 'arc', 'duration', 'width', 'length', 'spread', 'knockback', 'hp', 'delay'];
  const label = { damage: '伤害', cd: '冷却', count: '数量', radius: '范围', speed: '弹速', size: '体积', arc: '角度', duration: '持续', width: '宽度', length: '长度', spread: '散布', knockback: '击退', hp: '生命', delay: '延迟' };
  const out = [];
  for (const k of keys) {
    if (prev[k] === undefined || cur[k] === undefined) continue;
    if (prev[k] === cur[k]) continue;
    const a = Math.round(prev[k] * 100) / 100;
    const b = Math.round(cur[k] * 100) / 100;
    out.push(`<li>${label[k]} ${a} → <b>${b}</b></li>`);
  }
  return out.join('') || '<li>数值不变</li>';
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
}

// 卡片图标：直接取占位生成器画出的 dataURL，避免额外请求
// 卡片 / 暂停栏里的图标。
//
// 这里曾经直接调 getPlaceholder(slot) —— 那会**绕过 manifest 的 file 字段**，
// 于是"给 icon_* 槽位填了正式图"在 DOM 层完全无效，卡片上永远是程序生成的占位图；
// 而画布内的槽位面板走的是 getAsset()，两处显示的图标会对不上。
// 现在统一走 getAsset()：有 file 用 file，没 file 或加载失败才回退到占位图。
function iconDataUrl(slotId) {
  // 兜底：找不到槽位时用通用被动图标
  const slot = slotById(slotId) || slotById('icon_passive');
  try {
    const { source, isPlaceholder } = getAsset(slot.id);
    if (!isPlaceholder && source) {
      // source 是 Image 元素：画到临时 canvas 上取 dataURL（<img> 需要 URL 而不是元素）
      if (typeof source.toDataURL === 'function') return source.toDataURL();
      const c = document.createElement('canvas');
      c.width = source.width || slot.w;
      c.height = source.height || slot.h;
      const ctx = c.getContext('2d');
      ctx.drawImage(source, 0, 0, c.width, c.height);
      return c.toDataURL();
    }
    return getPlaceholder(slot).toDataURL();
  } catch (e) {
    // 任何异常都不能让卡片渲染失败（宁可显示占位图）
    try {
      return getPlaceholder(slot).toDataURL();
    } catch (e2) {
      return '';
    }
  }
}
