// 局外进度与存档（规格 §8 / §10）。
// 持久化：最高分 / 图鉴 / 试炼与解锁 / 命篆 / 设置 / 未完成的一局。
// 试炼解锁只提供内容；数值成长由命篆单独管理。
//
// 存档带版本号与迁移逻辑：旧局按原有战斗进度继续，缺失的命篆快照视为零级。

import { SAVE_KEY } from '../config.js';
import { SERIES_IDS, defaultInscriptions, normalizeInscriptions, compensateOldInscriptions } from './inscriptions.js';

export const SAVE_VERSION = 3;

function defaultSave() {
  return {
    v: SAVE_VERSION,
    createdAt: null,
    updatedAt: null,
    // 局外进度
    highScore: { kills: 0, timeMs: 0, level: 0, won: false, characterId: null },
    records: { maxTimeMs: 0, maxLevel: 0 },
    unlocks: {
      weapons: [], // 试炼解锁的武器 id
      series: ['shan', 'hai', 'huang'],
      characters: ['shanpo', 'haipo', 'huangpo'],
    },
    trials: {
      shan: { done: false, best: 0 },
      hai: { done: false, best: 0 },
      huang: { done: false, best: 0 },
      tian: { done: false, best: 0 },
      ling: { done: false, best: 0 },
      kun: { done: false, best: 0 },
      shan4: { done: false, best: 0 },
      hai4: { done: false, best: 0 },
      huang4: { done: false, best: 0 },
      tian4: { done: false, best: 0 },
      ling4: { done: false, best: 0 },
      kun4: { done: false, best: 0 },
    },
    counters: {
      killsTotal: 0,
      winsTotal: 0,
      winsByDifficulty: { normal: 0, hard: 0 },
      winsBySeries: Object.fromEntries(SERIES_IDS.map((id) => [id, 0])),
      winsByCharacter: { shanpo: 0, haipo: 0, huangpo: 0, tianpo: 0, wupo: 0, busipo: 0 },
    },
    codex: {}, // id -> true（记录"见过"而非"持有"）
    inscriptions: defaultInscriptions(),
    settings: {
      muted: false,
      volume: 0.7,
      quality: 'auto', // auto | high | low
      effects: true,
      shake: true,
      damageNumbers: true,
      devLabels: false,
    },
    unfinishedRun: null,
  };
}

let memFallback = null;

function storage() {
  try {
    if (typeof localStorage !== 'undefined') return localStorage;
  } catch (e) {
    /* 隐私模式等场景 */
  }
  return null;
}

export function loadSave() {
  const st = storage();
  if (!st) {
    if (!memFallback) memFallback = defaultSave();
    return memFallback;
  }
  let raw = null;
  try {
    raw = st.getItem(SAVE_KEY);
  } catch (e) {
    raw = null;
  }
  if (!raw) return defaultSave();
  let parsed = null;
  try {
    parsed = JSON.parse(raw);
  } catch (e) {
    // 存档损坏：不静默清空，保留原始串到一个备份键
    try {
      st.setItem(SAVE_KEY + '-corrupt', raw);
      st.removeItem(SAVE_KEY);
    } catch (e2) {
      /* 忽略 */
    }
    return defaultSave();
  }
  return migrate(parsed);
}

export function migrate(parsed) {
  const base = defaultSave();
  if (!parsed || typeof parsed !== 'object') return base;
  const v = parsed.v || 0;
  const out = { ...base, ...parsed };
  // 深合并关键子树，避免老存档缺字段
  out.unlocks = { ...base.unlocks, ...(parsed.unlocks || {}) };
  out.trials = { ...base.trials, ...(parsed.trials || {}) };
  out.counters = { ...base.counters, ...(parsed.counters || {}) };
  out.counters.winsByDifficulty = {
    normal: parsed.counters?.winsTotal || 0,
    hard: 0,
    ...(parsed.counters?.winsByDifficulty || {}),
  };
  out.counters.winsBySeries = { ...base.counters.winsBySeries, ...((parsed.counters && parsed.counters.winsBySeries) || {}) };
  out.counters.winsByCharacter = { ...base.counters.winsByCharacter, ...((parsed.counters && parsed.counters.winsByCharacter) || {}) };
  // 旧版胜场表只含开局三系；其余三系可从角色胜场还原。
  const characterSeries = { shanpo: 'shan', haipo: 'hai', huangpo: 'huang', tianpo: 'tian', wupo: 'ling', busipo: 'kun' };
  for (const [character, sid] of Object.entries(characterSeries)) {
    if (parsed.counters?.winsBySeries?.[sid] === undefined) {
      out.counters.winsBySeries[sid] = out.counters.winsByCharacter[character] || 0;
    }
  }
  out.settings = { ...base.settings, ...(parsed.settings || {}) };
  out.highScore = { ...base.highScore, ...(parsed.highScore || {}) };
  out.records = {
    maxTimeMs: Math.max(parsed.records?.maxTimeMs || 0, out.highScore.timeMs || 0),
    maxLevel: Math.max(parsed.records?.maxLevel || 0, out.highScore.level || 0),
  };
  out.codex = parsed.codex && typeof parsed.codex === 'object' ? parsed.codex : {};
  out.inscriptions = normalizeInscriptions(parsed.inscriptions);
  if (v !== SAVE_VERSION) {
    if (v < SAVE_VERSION) compensateOldInscriptions(out);
    // 旧局缺少命篆快照，续局时按零命篆处理；保留现有战斗进度。
    out.unfinishedRun = parsed.unfinishedRun || null;
    out.v = SAVE_VERSION;
    out.migratedFrom = v;
  } else if (parsed.unfinishedRun) {
    out.unfinishedRun = parsed.unfinishedRun;
  }
  if (!out.createdAt) out.createdAt = Date.now();
  return out;
}

export function persist(save) {
  save.updatedAt = Date.now();
  save.v = SAVE_VERSION;
  const st = storage();
  if (!st) {
    memFallback = save;
    return false;
  }
  try {
    st.setItem(SAVE_KEY, JSON.stringify(save));
    return true;
  } catch (e) {
    return false;
  }
}

export function clearSave() {
  const st = storage();
  if (st) {
    try {
      st.removeItem(SAVE_KEY);
    } catch (e) {
      /* 忽略 */
    }
  }
  memFallback = null;
}

/** 导出存档为 JSON 字符串（玩家自证/换机用） */
export function exportSave(save) {
  return JSON.stringify(save, null, 2);
}

export function importSave(text) {
  try {
    return migrate(JSON.parse(text));
  } catch (e) {
    return null;
  }
}

export { defaultSave };
