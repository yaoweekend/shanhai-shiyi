// 命篆：局外等级、灵蕴与归篆符。此模块只处理数据，不直接读写存档。
import { SERIES } from '../content/series.js';
import { CHARACTER_BY_ID } from '../content/characters.js';

export const SERIES_IDS = Object.keys(SERIES);
export const COMMON_NODES = [
  { id: 'maxHp', cn: '体魄', costs: [10, 20, 30], values: [10, 20, 30], unit: '生命' },
  { id: 'damage', cn: '锋芒', costs: [10, 20, 30], values: [2, 4, 6], unit: '% 伤害' },
  { id: 'speed', cn: '疾行', costs: [10, 20, 30], values: [2, 4, 6], unit: '% 移速' },
  { id: 'refresh', cn: '再择', costs: [15, 25], values: [1, 2], unit: '次额外刷新' },
];
export const SERIES_NODES = [
  { id: 'weapon', cn: '本系寻兵', costs: [15, 25], values: [2.1, 2.4], unit: '新武器权重' },
  { id: 'trait', cn: '本系真意', costs: [10, 20, 30] },
];
export const SERIES_TRAITS = {
  shan: { cn: '岩甲', channel: 'dr', values: [2, 4, 6], unit: '% 减伤' },
  hai: { cn: '逐浪', channel: 'projSpeed', values: [10, 20, 30], unit: '% 弹速' },
  huang: { cn: '荒域', channel: 'area', values: [6, 12, 18], unit: '% 范围' },
  tian: { cn: '问天', channel: 'critChance', values: [2, 4, 6], unit: '% 暴击率' },
  ling: { cn: '巫咒', channel: 'curse', values: [4, 8, 12], unit: '% 诅咒' },
  kun: { cn: '昆仑守', channel: 'shield', values: [10, 20, 30], unit: '护盾' },
};
export const SERIES_BALANCE_CAP = 200;
export const RESET_TICKET_CAP = 3;

const commonCosts = Object.fromEntries(COMMON_NODES.map((n) => [n.id, n.costs]));
const seriesCosts = Object.fromEntries(SERIES_NODES.map((n) => [n.id, n.costs]));

function integer(value, min, max) {
  return Number.isFinite(value) ? Math.max(min, Math.min(max, Math.floor(value))) : min;
}

export function defaultInscriptions() {
  return {
    common: { maxHp: 0, damage: 0, speed: 0, refresh: 0 },
    series: Object.fromEntries(SERIES_IDS.map((id) => [id, { weapon: 0, trait: 0 }])),
    balance: { common: 0, series: Object.fromEntries(SERIES_IDS.map((id) => [id, 0])) },
    resetTickets: 1,
    resetProgress: 0,
  };
}

export function normalizeInscriptions(raw) {
  const out = defaultInscriptions();
  if (!raw || typeof raw !== 'object') return out;
  for (const node of COMMON_NODES) out.common[node.id] = integer(raw.common?.[node.id], 0, node.costs.length);
  for (const sid of SERIES_IDS) {
    for (const node of SERIES_NODES) out.series[sid][node.id] = integer(raw.series?.[sid]?.[node.id], 0, node.costs.length);
    // 重置退还的灵蕴可以暂时超过 200；到低于上限前不会再发新灵蕴。
    out.balance.series[sid] = integer(raw.balance?.series?.[sid], 0, Number.MAX_SAFE_INTEGER);
  }
  out.balance.common = integer(raw.balance?.common, 0, Number.MAX_SAFE_INTEGER);
  out.resetTickets = integer(raw.resetTickets ?? out.resetTickets, 0, RESET_TICKET_CAP);
  out.resetProgress = integer(raw.resetProgress ?? out.resetProgress, 0, 2);
  return out;
}

function spent(levels, nodes) {
  return nodes.reduce((sum, node) => sum + node.costs.slice(0, levels[node.id] || 0).reduce((a, b) => a + b, 0), 0);
}

export function inscriptionRefund(state, scope) {
  return scope === 'common' ? spent(state.common, COMMON_NODES)
    : SERIES[scope] ? spent(state.series[scope], SERIES_NODES) : 0;
}

export function commonMaxed(state) {
  return COMMON_NODES.every((n) => state.common[n.id] >= n.costs.length);
}

export function seriesMaxed(state, sid) {
  return SERIES_NODES.every((n) => state.series[sid]?.[n.id] >= n.costs.length);
}

export function allSeriesMaxed(state) {
  return SERIES_IDS.every((sid) => seriesMaxed(state, sid));
}

export function buyInscription(save, scope, id) {
  const state = save.inscriptions;
  const isCommon = scope === 'common';
  const nodes = isCommon ? COMMON_NODES : SERIES_NODES;
  if (!isCommon && (!SERIES[scope] || !save.unlocks.series.includes(scope))) return false;
  const node = nodes.find((n) => n.id === id);
  const levels = isCommon ? state.common : state.series[scope];
  if (!node || !levels) return false;
  const level = levels[id];
  const cost = node.costs[level];
  const balance = isCommon ? state.balance.common : state.balance.series[scope];
  if (cost === undefined || balance < cost) return false;
  levels[id] = level + 1;
  if (isCommon) state.balance.common -= cost;
  else state.balance.series[scope] -= cost;
  return true;
}

export function convertInscriptions(save, source, target, amount) {
  const state = save.inscriptions;
  if (!SERIES[source] || !SERIES[target] || source === target) return false;
  if (!save.unlocks.series.includes(source) || !save.unlocks.series.includes(target)) return false;
  if (!Number.isSafeInteger(amount) || amount < 1 || seriesMaxed(state, target)) return false;
  if (state.balance.series[source] < amount * 2 || state.balance.series[target] + amount > SERIES_BALANCE_CAP) return false;
  state.balance.series[source] -= amount * 2;
  state.balance.series[target] += amount;
  return true;
}

export function resetInscriptions(save, scope) {
  const state = save.inscriptions;
  const isCommon = scope === 'common';
  if (!isCommon && (!SERIES[scope] || !save.unlocks.series.includes(scope))) return false;
  const levels = isCommon ? state.common : state.series[scope];
  const nodes = isCommon ? COMMON_NODES : SERIES_NODES;
  const refund = inscriptionRefund(state, scope);
  if (!refund || state.resetTickets < 1) return false;
  for (const node of nodes) levels[node.id] = 0;
  if (isCommon) state.balance.common += refund;
  else state.balance.series[scope] += refund;
  state.resetTickets -= 1;
  return refund;
}

export function runInscriptions(save, sid) {
  const state = save.inscriptions;
  return {
    common: { ...state.common },
    series: { ...(state.series[sid] || { weapon: 0, trait: 0 }) },
  };
}

export function normalizeRunInscriptions(raw) {
  const common = {};
  const series = {};
  for (const node of COMMON_NODES) common[node.id] = integer(raw?.common?.[node.id], 0, node.costs.length);
  for (const node of SERIES_NODES) series[node.id] = integer(raw?.series?.[node.id], 0, node.costs.length);
  return { common, series };
}

export function inscriptionChannelBonuses(levels, sid) {
  if (!levels) return {};
  const common = levels.common || {};
  const trait = SERIES_TRAITS[sid];
  const bonuses = {
    maxHp: 10 * (common.maxHp || 0),
    damage: 0.02 * (common.damage || 0),
    speed: 0.02 * (common.speed || 0),
  };
  if (trait) {
    const level = integer(levels.series?.trait, 0, trait.values.length);
    if (level) bonuses[trait.channel] = (bonuses[trait.channel] || 0) + trait.values[level - 1] * (trait.channel === 'shield' ? 1 : 0.01);
  }
  return bonuses;
}

export function inscriptionRewardAmount(result) {
  const elapsed = Math.max(0, result.rewardElapsedMs ?? result.elapsedMs ?? 0);
  const base = 1 + Math.min(15, Math.floor(elapsed / 60000));
  const hard = result.difficulty === 'hard';
  const timed = hard ? Math.max(1, Math.floor(base * 1.25)) : base;
  const killReward = result.endless ? Math.min(5, Math.floor(Math.max(0, result.rewardKills ?? result.kills ?? 0) / 2000)) : 0;
  return timed + killReward + (result.outcome === 'win' ? (hard ? 11 : 8) : 0);
}

export function awardInscriptions(save, result) {
  const state = save.inscriptions;
  const amount = inscriptionRewardAmount(result);
  const winBonus = result.outcome === 'win' ? (result.difficulty === 'hard' ? 11 : 8) : 0;
  const killReward = result.endless ? Math.min(5, Math.floor(Math.max(0, result.rewardKills ?? result.kills ?? 0) / 2000)) : 0;
  const sid = result.series || CHARACTER_BY_ID[result.characterId]?.series;
  const common = commonMaxed(state) ? 0 : amount;
  const series = SERIES[sid] && !allSeriesMaxed(state)
    ? Math.max(0, Math.min(amount, SERIES_BALANCE_CAP - state.balance.series[sid])) : 0;
  state.balance.common += common;
  if (series) state.balance.series[sid] += series;
  if (result.outcome === 'win' && state.resetTickets < RESET_TICKET_CAP) {
    state.resetProgress += result.difficulty === 'hard' ? 3 : 1;
    while (state.resetProgress >= 3 && state.resetTickets < RESET_TICKET_CAP) {
      state.resetProgress -= 3;
      state.resetTickets += 1;
    }
    if (state.resetTickets === RESET_TICKET_CAP) state.resetProgress = Math.min(2, state.resetProgress);
  }
  return { common, series, seriesId: sid, timeReward: amount - winBonus - killReward, killReward, winBonus, resetTickets: state.resetTickets, resetProgress: state.resetProgress };
}

export function compensateOldInscriptions(save) {
  const state = save.inscriptions;
  const counts = save.counters || {};
  const normal = integer(counts.winsByDifficulty?.normal, 0, Number.MAX_SAFE_INTEGER);
  const hard = integer(counts.winsByDifficulty?.hard, 0, Number.MAX_SAFE_INTEGER);
  state.balance.common = Math.min(110, normal * 20 + hard * 30);
  for (const sid of SERIES_IDS) state.balance.series[sid] = Math.min(50, integer(counts.winsBySeries?.[sid], 0, Number.MAX_SAFE_INTEGER) * 20);
  const earned = normal + hard * 3;
  state.resetTickets = Math.min(RESET_TICKET_CAP, 1 + Math.floor(earned / 3));
  state.resetProgress = state.resetTickets === RESET_TICKET_CAP ? 0 : earned % 3;
}
